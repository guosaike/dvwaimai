from rest_framework import serializers
from rest_framework.serializers import ModelSerializer
from . import models

class GuanliModelSerializers(ModelSerializer):
    """管理员信息模型序列化器"""
    username = serializers.CharField(read_only=True)

    class Meta:
        model = models.Guanli
        fields = '__all__'

class CsModelSerializers(ModelSerializer):
    """老板模型序列化器"""
    class Meta:
        model = models.Chushou
        fields = '__all__'

class GmModelSerializers(ModelSerializer):
    """游客模型序列化器"""
    class Meta:
        model = models.Goumai
        fields = '__all__'

class EsflModelSerializers(ModelSerializer):
    """分类模型序列化器"""
    class Meta:
        model = models.Fenlei
        fields = '__all__'

class EsdqModelSerializers(ModelSerializer):
    """地区模型序列化器"""
    class Meta:
        model = models.Diqu
        fields = '__all__'

class JqModelSerializers(ModelSerializer):
    class Meta:
        model = models.Waimai
        fields = '__all__'

class DdModelSerializers(ModelSerializer):
    """订单模型序列化器"""
    # 使用PublishSerializer作为publish字段的嵌套序列化器
    shui = GmModelSerializers(read_only=True)
    # 使用主键字段类型 并且将publish_id设置为"只写"，也就是读取的时候不会返回！
    shui_id = serializers.PrimaryKeyRelatedField(queryset=models.Goumai.objects.all(), source='shui',write_only=True)
    class Meta:
        model = models.Dingdan
        fields = '__all__'

class DzModelSerializers(ModelSerializer):
    """地址模型序列化器"""
    shui = GmModelSerializers(read_only=True)
    shui_id = serializers.PrimaryKeyRelatedField(queryset=models.Goumai.objects.all(), source='shui',write_only=True)
    class Meta:
        model = models.Addr
        fields = '__all__'